
package DVMarket;


public enum Estado {
    PENDIENTE, CANCELADA, CONFIRMADA;
}
